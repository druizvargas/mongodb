const mongoose = require('mongoose');

//Este modelo que vamos a hacer debe ser igual debe ser igual a lo que tenga la base de dato

const clienteSchema =mongoose.Schema({

    nombres:{
        type:String,
        require:true
    },
    apellidos:{
        type:String,
        require:true
    },
    cedula:{
        type:Number,
        require:true
    },
    correo:{
        type:String,
        require:true
    },
    telefono:{
        type:Number,
        require:true
    },
    direccion:{
        type:String,
        require:true
    },

},{versionkey: false});

module.exports = mongoose.model('Cliente',clienteSchema);