const mongoose = require("mongoose");


const proveedorSchema = mongoose.Schema({
    
    nit:{
        type:Number,
        require:true
    },
    nombre:{
        type:String,
        require:true
    },
    direccion:{
        type:String,
        require:true
    },
    telefono:{
        type:Number,
        require:true
    },
    correo:{
        type:String,
        require:true
    },
   

},{versionkey:false})

module.exports = mongoose.model('Proveedor',proveedorSchema);