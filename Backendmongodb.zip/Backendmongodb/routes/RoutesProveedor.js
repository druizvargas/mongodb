const express = require ('express');
const router = express.Router();
const ProveedorController = require('../controllers/ProveedorControllers');

router.post('/',ProveedorController.agregarProveedor);
router.get('/',ProveedorController.mostrarProveedor);
router.get('/:id',ProveedorController.mostrarunProveedor);
router.delete('/:id',ProveedorController.eliminarProveedor);
router.patch('/:id',ProveedorController.modificarProveedor);
router.put('/:id',ProveedorController.ActualizarProveedor);


module.exports = router;