const express = require ('express');
const router = express.Router();
const clienteController = require('../controllers/ClienteController');

//aca van las rutas de los crud
router.post('/',clienteController.agregarClientes);
router.get('/',clienteController.mostrarClientes);
router.get('/:id',clienteController.mostrarunCliente);
router.delete('/:id',clienteController.eliminarClientes);
//router.patch('/:id',clienteController.modificarCliente);
router.put('/:id',clienteController.actualizarCliente);
//router.put('/:id',clienteController.ActualizarClientes);


module.exports = router;