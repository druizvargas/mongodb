//Exportamos nuesto modelo
const Proveedor= require('../models/Proveedor');

//Funcion agregar proveedor

exports.agregarProveedor = async(req, res) =>{
    try {
        let proveedor = new Proveedor(req.body)
        await proveedor.save();
        res.send(proveedor);

        
    } catch (error) {
        console.log(error)
        res.status(500).send('Hubo un error al agregar un proveedor')
        
    }
}

// Funcion mostrar proveedores
exports.mostrarProveedor = async(req,res) =>{
    try {

      const proveedor = await Proveedor.find();
      res.json(proveedor);  
        
    } catch (error) {
        console.log(error)
        res.sattus(500).send('Hubo un error al agregar un provedores')
        
    }
} 
// Funcion mostrar un proveedor
exports.mostrarunProveedor = async(req,res) => {
    try {
        let proveedor= await Proveedor.findById(req.params.id);

        if(!proveedor){
            res.status(404).json({msg:"No se encuentra proveedor con ese id"});

        }
        res.send(proveedor);
       
   
    } catch (error) {
        console.log(error)
        res.status(500).send('Hubo un error al buscar un proveedor en la DB');
        
    }
}

//Funcion eliminar un proveedor
exports.eliminarProveedor = async(req, res) =>{

    try {

        let proveedor = await Proveedor.findById(req.params.id);
        if(!proveedor){
            res.status(404).json({msg:"El proveedor no existe"});
            return
        }

        await Proveedor.findOneAndDelete({_id: req.params.id});
        res.json({msg:"El proveedor fue eliminado"})

        
    } catch (error) {
        console.log(error)
        res.status(500).send('Hubo un error al eliminar un proveedor en la base de datos ')
        
    }
}
// Funcion modificar proveedor

exports.modificarProveedor = async(req,res) => {

    try {
        let proveedor = await Proveedor.findByIdAndUpdate(req.params.id, req.body,{new: true});
        if(!proveedor){
            return res.status(404).send('Proveedor no encontrado');
        }
        res.json(proveedor)

    } catch (error) {
        console.log(error);
        res.status(500).send('Hubo un error al modificar un Proveedor');
        
    }

}
// Funcion actualizar Proveedor

exports.ActualizarProveedor = async (req, res) => {
    try {
        let proveedor = await Proveedor.findByIdAndUpdate({_id: req.params.id},req.body);

        if(!proveedor) res.status(404).send("Proveedor no encontrado");
        else
        res.json(proveedor);
        
    } catch (error) {
        console.log(error);
        res.status(500).send("Hubo un error al actualizar un proveedor");
        
    }

}
