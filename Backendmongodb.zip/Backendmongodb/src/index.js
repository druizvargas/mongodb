const express = require ('express');
const conectarDB = require ('../config/db');
const cors = require ('cors');

// configuracion express y puerto

const app = express();
const port = 5000;
app.use(express.json());
//aca van las rutas de los modulos
app.use('/api/clients', require('../routes/RoutesCliente'));
app.use('/api/proveedor', require('../routes/RoutesProveedor'));

//Enlazamos la conexion de la base de datos 
conectarDB();
app.use(cors());

// se configura el puerto que va a tener nuestro servidor
app.listen(port, () => console.log('Servidor conectado http://localhost:5000'));

// se prueba esta ruta para el navegador
app.get('/',(req,res) => {

    res.send('Benvenido nuestro servidor esta configurado');

});